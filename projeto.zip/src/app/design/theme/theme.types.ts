export type ThemeMode = 'light' | 'dark';
export type FontSize = 'sm' | 'md' | 'lg' | 'xl';
